# encoding: utf-8

class Metrics::Starp_metric < Metrics::AM
  #this is for Metrics with type=Starp_metric
  #Override methods here

  def self.getLoScore(evData)
  	super
  end
end