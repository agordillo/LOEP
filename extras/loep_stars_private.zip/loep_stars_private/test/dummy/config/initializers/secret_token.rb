# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Dummy::Application.config.secret_token = '07bdb35c7bae293087a10668f9e8bd4c3601b39326ee513ac423f4c8e6189e5a8da1b2c4367e5bf97bd0cbca5347c0bd1ed71d77e0ccf72135cc5ca3334e1294'
