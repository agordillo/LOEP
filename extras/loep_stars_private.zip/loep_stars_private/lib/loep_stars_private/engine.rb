module LoepStarsPrivate
  class Engine < ::Rails::Engine
  end
end
